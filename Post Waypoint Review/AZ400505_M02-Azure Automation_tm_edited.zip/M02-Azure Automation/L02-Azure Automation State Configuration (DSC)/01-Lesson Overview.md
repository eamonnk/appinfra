

This lesson includes the following topics:

- Desired State Configuration (DSC)
- Azure Automation State configuration (DSC)
- DSC configuration file
- Walkthrough-Import and Compile
- Walkthrough-Onboarding machines for management
- Hybrid management
- DSC and Linux automation on Azure
