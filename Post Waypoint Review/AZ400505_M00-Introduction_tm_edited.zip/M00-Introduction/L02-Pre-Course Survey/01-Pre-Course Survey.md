## Survey

## Survey Introduction
Please complete the survey below before starting the course. If the survey is not available in your browser, select this link to [Microsoft AZ-400.5: Implementing Application Infrastructure Course Survey](https://wwlcoursesurveys.azurewebsites.net?surveyId=2070) to open it in a separate pane.

---
## Survey  
<p><iframe width="100%" height="1000" title="Pre-course survey" src=" https://wwlcoursesurveys.azurewebsites.net?surveyId=2070" frameborder="0" marginwidth="0" marginheight="0" scrolling="yes">
Your browser does not support IFrames.
</iframe></p>  
