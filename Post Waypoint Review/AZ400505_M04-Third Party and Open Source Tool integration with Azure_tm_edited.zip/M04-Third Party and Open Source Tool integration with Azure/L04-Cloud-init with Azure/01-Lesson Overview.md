

This lesson includes the following topics:

- What is cloud-init?
- Cloud-init components
- Cloud-init on Azure
- Configure a Linux VM using cloud-init and Azure Cloud Shell
