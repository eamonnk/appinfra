###### Enter the Lesson Title
```
Lesson title: Lab
```
