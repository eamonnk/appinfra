

This lesson includes the following topics:

- Azure virtual machines
- Scaling Azure VMs
- Walkthrough: Create a VM scale set
- Availability
- Additional IaaS considerations
- VMs versus containers
- Azure VMs and containers
- Windows Server and Hyper-V containers
- Azure VMs and containers
- Automating IaaS Infrastructure
