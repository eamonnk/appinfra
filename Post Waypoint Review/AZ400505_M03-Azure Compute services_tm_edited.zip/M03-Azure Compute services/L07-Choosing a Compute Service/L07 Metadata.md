###### Enter the Lesson Title
```
Lesson title: Choosing a Compute Service
```
