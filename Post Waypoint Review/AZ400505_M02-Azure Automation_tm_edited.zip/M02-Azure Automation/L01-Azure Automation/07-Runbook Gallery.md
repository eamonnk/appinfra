
Azure Automation runbooks are provided to help eliminate the time it takes to build custom solutions. These runbooks have already been built by Microsoft and the Microsoft community, and you can use them with or without modification. You can import runbooks from the runbook gallery at the Microsoft Script Center, <a href="https://gallery.technet.microsoft.com/scriptcenter/site/search?f[0].Type=RootCategory&f[0].Value=WindowsAzure&f[1].Type=SubCategory&f[1].Value=WindowsAzure_automation&f[1].Text=Automation" target="_blank"><span style="color: #0066cc;" color="#0066cc">Script resources for IT professionals</span></a> webpage.

> **Note**: A new Azure PowerShell module was released in December 2018, called the **Az** PowerShell module. This replaces the existing **AzureRM** PowerShell module, and is now the intended PowerShell module for interacting with Azure. This new **Az** module is now supported in Azure Automation. For more details on its use with Azure Automation, visit <a href="https://docs.microsoft.com/en-us/azure/automation/az-modules" target="_blank"><span style="color: #0066cc;" color="#0066cc">Az module support in Azure Automation</span></a>. For more general details on the new Az PowerShell module, go to <a href="https://docs.microsoft.com/en-us/powershell/azure/new-azureps-module-az?view=azps-2.7.0" target="_blank"><span style="color: #0066cc;" color="#0066cc">Introducing the new Azure PowerShell Az module</span></a>.

### Choosing items from the runbook gallery
In the Azure portal, you can import directly from the runbook gallery using the following  high-level steps:

1. Open your Automation account, and then select **Process Automation** > **Runbooks**.
2. In the runbooks pane, select **Browse gallery**.
3. From the runbook gallery, locate the runbook gallery item that you want, select it, and then select **Import**.

When browsing through the runbooks in the script center library, you can review the code or a visualization of the code. You also can review information such as the source project along with a detailed description, ratings, and questions and answers. For more information, refer to <a href="https://gallery.technet.microsoft.com/scriptcenter" target="_blank"><span style="color: #0066cc;" color="#0066cc">Script resources for IT professionals</span></a>.

<p style="text-align:center;"><img src="../Linked_Image_Files/runbookgallery1.png" alt="Screenshot of Star Azure V2 VMs runbook in the runbook gallery in Azure Automation. Both the Import and View Source Project options are highlighted. A graphical diagram of the runbook also displays."></p>

> **Note**: Python runbooks are also available from the script center gallery. To find them, filter by language and select **Python**.

> **Note**: You cannot use PowerShell to import directly from the runbook gallery.
