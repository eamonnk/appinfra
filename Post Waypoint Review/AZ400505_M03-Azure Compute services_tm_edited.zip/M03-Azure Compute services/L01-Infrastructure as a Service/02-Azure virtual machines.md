A Microsoft Azure virtual machine (VM) provides the flexibility of virtualization without having to buy and maintain the physical hardware that runs it. However, you still need to maintain the VM by performing tasks such as deploying, configuring, and maintaining the software that runs on it. Azure VMs provides more control over computing environments than other choices offer.

### Operating system support
Azure virtual machines supports both Windows operating system (OS) and Linux OS deployments. You can also choose to upload and use your own image.

> **Note**: If you opt to use your own image, the publisher name, offer, and SKU aren’t used.

#### Windows operating systems
Azure provides both Windows Server and Windows client images for use in development, test, and production. Azure provides several marketplace images to use with various versions and types of Windows Server operating systems. Marketplace images are identified by image publisher, offer, SKU, and version (typically version is specified as latest). However, only 64-bit operating systems are supported.

As an example, to find and list available Windows Server SKUs in westeurope, run the following commands one after the other:

```
bash
az vm image list-publishers --location westeurope --query "[?starts_with(name, 'Microsoft')]"
az vm image list-offers --location westeurope --publisher MicrosoftWindowsServer
az vm image list-skus --location westeurope --publisher MicrosoftWindowsServer --offer windowsserver
```

#### Linux
Azure provides endorsed Linux distributions. *Endorsed distributions* are distributions that are available on Azure Marketplace and are fully supported. The images in Azure Marketplace are provided and maintained by the Microsoft partner who produces them. Some of the endorsed distributions available in Azure Marketplace include:

- CentOS
- CoreOS
- Debian
- Oracle Linux
- Red Hat
- SUSE Linux Enterprise
- OpenSUSE
- Ubuntu
- RancherOS

There are several other Linux-based partner products that you can deploy to Azure VMs, including Docker, Bitnami by VMWare, and Jenkins. A full list of endorsed Linux distributions is available at <a href="https://docs.microsoft.com/en-us/azure/virtual-machines/linux/endorsed-distros" target="_blank"><span style="color: #0066cc;" color="#0066cc">Endorsed Linux distributions on Azure</span></a>.

As an example, to find and list available RedHat SKUs in westus, run the following commands one after the other:

```bash
az vm image list-publishers --location westus --query "[?contains(name, 'RedHat')]"
az vm image list-offers --location westus --publisher RedHat
az vm image list-skus --location westus --publisher RedHat --offer RHEL
```

If you want to use a Linux version not on the endorsed list and not available in Azure Marketplace, you can install it directly.

### Azure VMs usage scenarios
You can use Azure VMs in various ways. Some examples are:

- Development and test. Azure VMs offer a quick and easier way to create a computer with specific configurations that are required to code and test an application.
- Applications in the cloud. Because demand for an application can fluctuate, it might make economic sense to run it on a VM in Azure. You pay for extra VMs when you need them, and shut them down when you don’t.
- Extended datacenter. VMs in an Azure virtual network can more easily be connected to your organization’s network. 

The number of VMs that your application uses can scale up and out to whatever is required to meet your needs. Conversely, it can scale back down when you don't need it, thereby avoiding unnecessary charges.

### Deployment, configuration management and extensions
Azure VMs support a number of deployment and configuration management toolsets, including:

- Azure Resource Manager (ARM) templates
- Windows PowerShell Desired State Configuration (DSC)
- Ansible
- Chef
- Puppet
- Terraform by HashiCorp

VM extensions give your VM additional capabilities through post-deployment configuration and automated tasks. Some common tasks you can complete using extensions include:

- Running custom scripts. The Custom Script Extension (CSE) helps you configure workloads on the VM by running your script when you provision the VM.
- Deploying and managing configurations. The PowerShell DSC extension helps you set up DSC on a VM to manage configurations and environments.
- Collect diagnostics data. The Azure Diagnostics extension helps you configure the VM to collect diagnostics data that you can use to monitor your application's health.

### Azure VM service limits and ARM
Each Azure service has its own service limits, quotas, and constraints. For example, some of the service limits for VMs when you use ARM and Azure resource groups are in the following table.

| Resource | Default Limit |
| --- | --- | --- |
| VMs per availability set | 200 |
|  Certificates per subscription | Unlimited |