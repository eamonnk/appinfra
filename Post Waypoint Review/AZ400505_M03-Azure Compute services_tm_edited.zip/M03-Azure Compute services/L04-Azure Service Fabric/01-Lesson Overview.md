

This lesson includes the following topics:

- Microsoft Azure Service Fabric overview
- Application model
- Programming models
- Scaling Azure clusters
- Create clusters anywhere
- Walkthrough-Create a standalone on Windows Server
- Placement constraints
- Configure monitoring and logging overview
- Backup and recovery
- Walkthrough-Docker Compose deployment to Service Fabric
