

This lesson includes the following topics:

- Azure App Service
- App Service plans
- Walkthrough-Create a Java app in App Service on Linux
- Walkthrough-Deploy a .NET Core-based app
- Scale App Services
- Web App for containers
- Walkthrough-Deploy a custom Docker image to Web App for containers
- Azure Container Instances
- Walkthrough-Create a container on ACI
