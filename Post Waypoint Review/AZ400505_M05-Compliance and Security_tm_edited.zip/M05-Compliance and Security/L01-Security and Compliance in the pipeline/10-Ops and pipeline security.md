
In addition to protecting your code, it's essential to protect credentials and secrets. In particular, phishing is becoming ever more sophisticated. The following list is several operational practices that a team ought to apply to protect itself:

- Authentication and authorization. Use multifactor authentication (MFA)—even across internal domains—and just-in-time administration tools such as Azure PowerShell <a href="http://aka.ms/jea" target="_blank"><span style="color: #0066cc;" color="#0066cc">Just Enough Administration (JEA)</span></a>, to protect against escalations of privilege. Using different passwords for different user accounts will limit the damage if a set of access credentials is stolen.

- The CI/CD Release Pipeline. If the release pipeline and cadence are damaged, use this pipeline to rebuild infrastructure. If you manage Infrastructure as Code (IaC) with  Azure Resource Manager, or use the Azure platform as a service (PaaS) or a similar service, then your pipeline will automatically create new instances and then destroy them. This limits the places where attackers can hide malicious code inside your infrastructure. Azure DevOps will encrypt the secrets in your pipeline, as a best practice rotate the passwords just as you would with other credentials.

- Permissions management. You can manage permissions to secure the pipeline with role-based access control (RBAC), just as you would for your source code. This keeps you in control of who can edit the build and release definitions that you use for production.

- Dynamic scanning. This is the process of testing the running application with known attack patterns. You could implement penetration testing as part of your release. You also could keep up to date on security projects such as the Open Web Application Security Project (<a href="https://www.owasp.org" target="_blank"><span style="color: #0066cc;" color="#0066cc">OWASP</span></a>) Foundation, then adopt these projects into your processes.

- Production monitoring.  This is a key DevOps practice. The specialized services for detecting anomalies related to intrusion are known as *Security Information and Event Management*. <a href="https://azure.microsoft.com/en-us/services/security-center/" target="_blank"><span style="color: #0066cc;" color="#0066cc">Azure Security Center</span></a> focuses on the security incidents that relate to the Azure cloud.

> **Note**: In all cases, use Azure Resource Manager Templates or other code-based configurations. You should also implement IaC best practices, such as only making changes in templates, to make changes traceable and repeatable. Also, use provisioning and configuration technologies such as Desired State Configuration (DSC), Azure Automation, and other third-party tools and products that can integrate seamlessly with Azure.

