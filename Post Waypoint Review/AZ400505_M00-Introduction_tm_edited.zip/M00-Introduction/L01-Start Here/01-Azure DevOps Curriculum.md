Welcome to the **Implementing Application Infrastructure** course. This course is part of a series of courses to help you prepare for the AZ-400, [Microsoft Azure DevOps Solutions](https://www.microsoft.com/en-us/learning/exam-AZ-400.aspx) certification exam. 
The DevOps certification exam is for DevOps professionals who combine people, processes, and technologies to continuously deliver valuable products and services that meet end user needs and business objectives. 

DevOps professionals streamline delivery by optimizing practices, improving communications and collaboration, and creating automation. They design and implement strategies for application code and infrastructure that allow for continuous integration, testing, delivery, and monitoring and feedback.

Exam candidates must be proficient with Agile practices. They must be familiar with both Microsoft Azure administration and Azure development, and be proficient in at least one of these areas. Azure DevOps professionals must be able to design and implement DevOps practices for:

- Version control
- Compliance
- Infrastructure as Code
- Configuration management
- Build, release, and testing by using Azure technologies 

There are seven exam study areas. Each study area has a corresponding course. While it's not required that you complete any of the other courses in the DevOps series before taking this course, it is strongly recommended that you start with the first course in the series, and progress through the courses in order. In particular, make sure you have completed the **Design a DevOps Strategy **course so that you have a greater understanding of DevOps before focusing more on specific methodologies.

| AZ-400 Study areas| Weights |
| - | - |
| Implement DevOps Development Processes| 20-25 percent |
| Implement Continuous Integration | 10-15 percent |
| Implement Continuous Delivery | 10-15 percent |
| Implement Dependency Management | 5 -10 percent |
| **Implement Application Infrastructure** | 15-20 percent |
| Implement Continuous Feedback | 10-15 percent |
| Design a DevOps Strategy| 20-25 percent |

This course will focus on preparing you for the *Implement Application Infrastructure* area of the AZ-400 certification exam.