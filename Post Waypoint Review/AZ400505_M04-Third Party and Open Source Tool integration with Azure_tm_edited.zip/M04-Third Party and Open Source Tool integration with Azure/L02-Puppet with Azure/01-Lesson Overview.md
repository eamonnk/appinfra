

This lesson includes the following topics:

- What is Puppet?
- Deploying Puppet in Azure
- Manifest files