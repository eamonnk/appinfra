*Azure Batch* is a fully managed cloud service that provides job scheduling and compute resource management. It creates and manages a pool of compute nodes (VMs), installs the applications you want to run, and schedules jobs to run on the nodes. It enables applications, algorithms, and computationally intensive workloads to be broken out into individual tasks for execution. This enables them to be easily and efficiently run in parallel at scale.

Using Azure Batch, there is no cluster or job scheduler software to install, manage, or scale. Instead, you use Batch APIs and tools, command-line scripts, or the Azure portal to configure, manage, and monitor your jobs. 

### Usage scenarios and application types 

The following topics are just some of the usage scenarios for Azure Batch.

#### Independent parallel
This is the most commonly used scenario. The applications or tasks don't communicate with each other, but instead operate independently. The more VMs or nodes you can bring to a task, the more quickly it will complete. Examples of usage would be Monte Carlo risk simulations, transcoding, and rendering a movie frame by frame.
    <p style="text-align:center;"><img src="../Linked_Image_Files/batchservice-parallel.png" alt="A box with a dashed-line border contains four VMs, each with an image of an application overlaying the VM."></p>


#### Communication
From traditional high-performance computing (HPC) such as scientific computing, or computing and engineering tasks, applications or tasks communicate with each other. They would typically use the Message Passing Interface (MPI) API for this inter-node communication. However, they can also use low-latency, high-bandwidth Remote Direct Memory Access (RDMA) networking. Examples of usage would be car crash simulations, fluid dynamics, and Artificial Intelligence (AI) training frameworks. 
    <p style="text-align:center;"><img src="../Linked_Image_Files/batchservice-tightlycoupled.png" alt="A box with a dashed-line border contains four VMs, each with an image of an application overlaying the VM. Lines with bi-directional arrows link each VM to each other VM, indicating that they communicate with each other. "></p>

#### Multiple tightly coupled in parallel
You can also expand on this tightly coupled MPI scenario. For example, instead of having four nodes carrying out a job, you can have 40 nodes and run the job 10 times in parallel to scale out the job task.
    <p style="text-align:center;"><img src="../Linked_Image_Files/batchservice-mltitightlycoupledpatellel.png" alt="Two boxes with dashed-line borders contain four VMs each, with each VM containing an image of an application overlaying the VM. Lines with bi-directional arrows link each VM to the other VMs in the box, indicating that they communicate with each other."></p>

### Batch Service components
Batch service primarily consists of two components:

- Resource management. Batch service manages resources by creating, managing, monitoring, and scaling the pool (or pools) of VMs, which are required to run the application. You can scale from a few VMs up to tens of thousands of VMs, enabling you to run the largest, most resource-intensive workloads. Furthermore, no on-premises infrastructure is required.
- Job Scheduler. Batch service provides a job scheduler. You submit your work via jobs, which are effectively a series of tasks, and specify individual tasks into the VM pool (or set of VM pools).

### Running an application

To get an application to run, you must have the following items:

- An application. This could just be a standard desktop application; it doesn't need to be cloud aware.
- Resource management. You need a pool of VMs, which Batch service creates, manages, monitors, and scales.
- A method to get the application onto the VMs. You can:
    - Store the application in blob storage, and then copy it onto each VM.
    - Have a container image and deploy it.
    - Upload a zip or application package.
    - Create a custom VM image, then upload and use that.
 - Job scheduler. Create and define the tasks that will combine to make the job.
 - Output Storage: You need somewhere to place the output data, typically use Blob storage.

> **Note** The unit of execution is what can be run on the command line in the VM. The application itself does not need to be repackaged.

### Cost
Batch services provide:

- The ability to scale VMs as needed.
- The ability to increase and decrease resources on demand.
- Efficiency, as it makes best use of the resources.
- Cost effectiveness, because you only pay for the infrastructure you use when you are using it.

> **Note**: There is no additional charge for using a Batch service. You only pay for the underlying resources consumed, such as the VMs, storage, and networking.
