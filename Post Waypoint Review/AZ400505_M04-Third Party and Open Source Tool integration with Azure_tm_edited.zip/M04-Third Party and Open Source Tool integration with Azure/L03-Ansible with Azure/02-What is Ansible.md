

*Ansible* is an open-source platform by Red Hat that automates cloud provisioning, configuration management, and application deployments. Using Ansible, you can provision VMs, containers, and your entire cloud infrastructure. In addition to provisioning and configuring applications and their environments, Ansible enables you to automate deployment and configuration of resources in your environment such as virtual networks, storage, subnets, and resources groups. 

Ansible is designed for multiple tier deployments. Unlike Puppet or Chef, Ansible is *agentless*, meaning you don't have to install software on the managed machines.

Ansible also models your IT infrastructure by describing how all of your systems interrelate, rather than managing just one system at a time.
