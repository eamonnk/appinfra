

This lesson includes the following topics:

- What is Chef
- Chef Automate
- Chef Cookbooks
- Chef Knife command