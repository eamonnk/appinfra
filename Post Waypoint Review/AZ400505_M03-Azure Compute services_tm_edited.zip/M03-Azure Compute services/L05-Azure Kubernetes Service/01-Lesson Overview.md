

This lesson includes the following topics:

- Kubernetes overview
- Azure Kubernetes Service
- AKS Architectural components
- Kubernetes networking
- Deployment
- Walkthrough-Deploying and connecting to an AKS cluster.
- Continuous deployment
- Updating images
