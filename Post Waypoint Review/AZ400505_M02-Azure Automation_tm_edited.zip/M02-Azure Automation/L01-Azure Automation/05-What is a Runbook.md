
*Runbooks* serve as repositories for your custom scripts and workflows. They also typically reference Automation shared resources such as credentials, variables, connections, and certificates. Runbooks can also contain other runbooks, thereby allowing you to build more complex workflows. You can invoke and run runbooks either on demand, or according to a schedule by leveraging Automation Schedule assets.

<p style="text-align:center;"><img src="../Linked_Image_Files/createarunbook.png" alt="Screenshot of the Add Runbook window. In the left pane, Quick Create: Create a new runbook is selected. In the right pane, the Runbook type drop-down menu displays options such as PowerShell, Python 2, Graphical, and Other. Under Other is PowerShell Workflow, and Graphical PowerShell workflow."></p>

### Creating runbooks

When creating runbooks, you have two options. You can either:

- Create your own runbook and import it. For more information about creating or importing a runbook in Azure Automation, go to <a href="https://docs.microsoft.com/en-us/azure/automation/automation-creating-importing-runbook" target="_blank"><span style="color: #0066cc;" color="#0066cc">Manage runbooks in Azure Automation</span></a>.
- Modify runbooks from the runbook gallery. This provides a rich ecosystem of runbooks that are available for your requirements. Visit <a href="https://docs.microsoft.com/en-us/azure/automation/automation-runbook-gallery" target="_blank"><span style="color: #0066cc;" color="#0066cc">Runbook and module galleries for Azure Automation</span></a> for more information.

There is also a vibrant open-source community that creates runbooks you can apply directly to your use cases. 

You can choose from different runbook types based on your requirements and Windows PowerShell experience. If you prefer to work directly with Windows PowerShell code, you can use either a PowerShell runbook, or a PowerShell Workflow runbook. Using either of these you can edit offline or with the textual editor in the Azure portal. If you prefer to edit a runbook without being exposed to the underlying code, you can create a graphical runbook by using the graphical editor in the Azure portal.

### Graphical runbooks
Graphical runbooks and Graphical PowerShell Workflow runbooks are created and edited with the graphical editor in the Azure portal. You can export them to a file and then import them into another automation account, but you cannot create or edit them with another tool.

### PowerShell runbooks
PowerShell runbooks are based on Windows PowerShell. You edit the runbook code directly, using the text editor in the Azure portal. You can also use any offline text editor and then import the runbook into Azure Automation. PowerShell runbooks do not use parallel processing.

### PowerShell Workflow runbooks
PowerShell Workflow runbooks are text runbooks based on Windows PowerShell Workflow. You directly edit the runbook code using the text editor in the Azure portal. You can also use any offline text editor and import the runbook into Azure Automation. 

PowerShell Workflow runbooks use parallel processing to allow for simultaneous completion of multiple tasks. Workflow runbooks take longer to start than PowerShell runbooks because they must be compiled prior to running.

### Python runbooks
Python runbooks compile under Python 2. You can directly edit the code of the runbook using the text editor in the Azure portal, or you can use any offline text editor and import the runbook into Azure Automation. You can also utilize Python libraries. However, only Python 2 is supported at this time. To utilize third-party libraries, you must first import the package into the Automation Account.

> **Note**: You can't convert runbooks from graphical to textual type, or vice versa.

For more information on the different types of runbooks, visit <a href="https://azure.microsoft.com/en-us/documentation/articles/automation-runbook-types" target="_blank"><span style="color: #0066cc;" color="#0066cc">Azure Automation runbook types</span></a>.


