

This lesson includes the following topics:

- What is Azure automation
- Automation accounts
- Automation shared resources
- What is a runbook
- Automating processes with runbooks
- Runbook gallery
- Webhooks
- Source control integration
- Update management
- PowerShell workflows
- Creating a workflow
- Walkthrough-Create and run a workflow runbook
- Checkpoint and parallel processing
