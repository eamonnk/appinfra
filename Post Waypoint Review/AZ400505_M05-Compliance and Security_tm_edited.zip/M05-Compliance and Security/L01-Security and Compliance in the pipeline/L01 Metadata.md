###### Enter the Lesson Title
```
Lesson title: Security and Compliance in the pipeline
```
