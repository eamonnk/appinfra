###### Enter the Lesson Title
```
Lesson title: Azure Automation State Configuration (DSC)
```
