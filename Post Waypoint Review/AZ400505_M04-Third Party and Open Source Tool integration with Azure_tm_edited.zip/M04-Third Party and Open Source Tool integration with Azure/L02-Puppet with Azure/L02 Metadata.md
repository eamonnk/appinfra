###### Enter the Lesson Title
```
Lesson title: Puppet with Azure
```
