
The following workflow and component diagram outlines how playbooks can run in different circumstances, one after another. In the workflow, Ansible playbooks:

<p style="text-align:center;"><img src="../Linked_Image_Files/ansibleworkflow.png" alt="The Ansible workflow has three general areas. On the left is a box containing a user and three Ansible playbooks. In order, they: provision resources, configure application, and future configuration to scale. Each playbook has an arrow that points to a box in the middle of the graphic containing Ansible Automation components, which are Roles, Modules, APIs, Plugins, and Inventory. These two boxes are within a control machine box. From the components box, three arrows point to Azure resources, an application, and three images representing the scaling of the application."></p>

1. Provision resources. Playbooks can provision resources. In the following diagram, playbooks create load-balancer virtual networks, network security groups, and VM scale sets on Azure.
2. Configure the application. Playbooks can deploy applications to run particular services, such as installing Apache Tomcat on a Linux machine to allow you to run a web application.
3. Manage future configurations to scale. Playbooks can alter configurations by applying playbooks to existing resources and applications—in this instance to scale the VMs.

In all cases, Ansible makes use of core components such as roles, modules, APIs, plugins, inventory, and other components.

> **Note**: By default, Ansible manages machines using the *ssh* protocol.

> **Note**: You don't need to maintain and run commands from any particular central server. Instead, there is a control machine with Ansible installed, and from which playbooks are run.

### Ansible core components
Ansible models your IT infrastructure by describing how all of your systems interrelate, rather than just managing one system at a time. The core components of Ansible are:

- Control Machine. This is the machine from which the configurations are run. It can be any machine with Ansible installed on it. However, it requires that Python 2 or Python 3 be installed on the control machine as well.  You can have multiple control nodes, laptops, shared desktops, and servers all running Ansible.

- Managed Nodes. These are the devices and machines (or just machines) and environments that are being managed. Managed nodes are sometimes referred to as *hosts*. Ansible is not installed on nodes. 

- Playbooks. Playbooks are ordered lists of tasks that have been saved so you can run them repeatedly in the same order. Playbooks are Ansible’s language for configuration, deployment, and orchestration. They can describe a policy that you want your remote systems to enforce, or they can dictate a set of steps in a general IT process. 

    When you create a playbook, you do so using YAML, which defines a model of a configuration or process, and uses a declarative model. Elements such as **name**, **hosts**, and **tasks** reside within playbooks.

- Modules. Ansible works by connecting to your nodes, and then pushing small programs (or *units of code*)—called *modules*—out to the nodes. *Modules* are the units of code that define the configuration. They are modular, and can be reused across playbooks. They represent the desired state of the system (declarative), are executed over SSH by default, and are removed when finished. 

    A playbook is typically made up of many modules. For example, you could have one playbook containing three modules: a module for creating an Azure Resource group, a module for creating a virtual network, and a module for adding a subnet.  

    Your library of modules can reside on any machine, and do not require any servers, daemons, or databases. Typically, you’ll work with your favorite terminal program, a text editor, and most likely a version control system to track changes to your content. A complete list of  available modules is available on Ansible's <a href="https://docs.ansible.com/ansible/latest/modules/list_of_all_modules.html" target="_blank"><span style="color: #0066cc;" color="#0066cc">All modules</span></a> page.

    You can find details of the Ansible modules that are available for Azure on GitHub at <a href="https://github.com/ansible/ansible/tree/devel/lib/ansible/modules/cloud/azure" target="_blank"><span style="color: #0066cc;" color="#0066cc">GitHub' Ansible Azure</span></a> webpage. You can also preview Ansible Azure modules on the Ansible <a href="https://galaxy.ansible.com/Azure/azure_preview_modules" target="_blank"><span style="color: #0066cc;" color="#0066cc">Azure preview modules</span></a> webpage.

- Inventory. An *inventory* is a list of managed nodes. Ansible represents what machines it manages using a .INI file that puts all your managed machines in groups of your own choosing. When adding new machines, you don't need to use additional SSL-signing servers, thus avoiding Network Time Protocol (NTP) and Domain Name System (DNS) issues. You can create the inventory manually, or for Azure, Ansible supports dynamic inventories> This means that the host inventory is dynamically generated at runtime. Ansible supports host inventories for other managed hosts as well.

- Roles. *Roles* are predefined file structures that allow automatic loading of certain variables, files, tasks, and handlers, based on the file's structure. It allows for easier sharing of roles. You might, for example, create roles for a web server deployment.

- Facts. *Facts* are data points about the remote system that Ansible is managing. When a playbook is run against a machine, Ansible will gather facts about the state of the environment to determine the state before executing the playbook.

- Plug-ins. *Plug-ins* are code that supplements Ansible's core functionality.

