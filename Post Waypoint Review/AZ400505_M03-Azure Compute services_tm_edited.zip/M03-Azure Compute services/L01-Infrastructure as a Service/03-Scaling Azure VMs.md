
### Scaling Azure VMs
Scale is provided for in Azure virtual machines (VMs) using VM scale sets (or *VMSS*). Azure VM scale sets let you create and manage a group of identical, load-balanced VMs. The number of VM instances can automatically increase or decrease in response to demand or a defined schedule. Scale sets provide high availability to your applications, and allow you to centrally manage, configure, and update a large number of VMs. With VM scale sets, you can build large-scale services for areas such as compute, big data, and container workloads.

#### Why and when to use VM scale sets
Azure VM scale sets provide the management capabilities for applications that run across many VMs, automatic scaling of resources, and load-balancing of traffic. Scale sets provide the following key benefits:
- Easier to create and manage multiple VMs
- Provide high availability and application resiliency
- Allow your application to automatically scale as resource demand changes
- Work at large-scale
- Useful when deploying highly available infrastructure where a set of machines has similar configurations

There are two basic ways to configure VMs deployed in a scale set:
- Use extensions to configure the VM after it's deployed. With this approach, new VM instances could take longer to start than a VM with no extensions.
- Deploy a managed disk with a custom disk image. This option might be quicker to deploy, but it requires you to keep the image up to date.

#### Differences between virtual machines and scale sets
Scale sets are built from VMs. With scale sets, the management and automation layers are provided to run and scale your applications. However, you also could manually create and manage individual VMs, or integrate existing tools to build a similar level of automation. The following table outlines the benefits of scale sets compared to manually managing multiple VM instances.

| Scenario | Manual group of VMs | VM scale set
| --- | --- | --- |
| Add additional VM instances | Manual process to create, configure, and ensure compliance | Automatically create from central configuration |
| Traffic balancing and distribution | Manual process to create and configure Azure Load Balancer or Application Gateway | Can automatically create and integrate with Azure Load Balancer or Application Gateway|
| High availability and redundancy | Manually create an availability set or distribute and track VMs across availability zones | Automatic distribution of VM instances across availability zones or availability sets |
| Scaling of VMs | Manual monitoring and Azure Automation | Autoscale based on host metrics, in-guest metrics, Application Insights, or schedule |


#### VM scale set limits
Each Azure service has service limits, quotas, and constraints. Some of the service limits for VM scale sets are listed in the following table.

| Resource | Default limit | Maximum limit |
| --- | --- | --- |
| Maximum number of VMs in a scale set |1,000 |1,000|
| Maximum number of scale sets in a region| 600 | 600|
| Maximum number of scale sets in a region| 2,000 | 2,000 |


> **NOTE**: There is no additional cost to use the VM scale sets service. You only pay for the underlying compute resources such as the VM instances, Azure Load Balancer, or managed disk storage that you consume. The management and automation features, such as autoscale and redundancy, incur no additional charges over the use of VMs.
