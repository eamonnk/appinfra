

This lesson includes the following topics:

- Serverless computing
- Functions as a service
- Azure Functions
- Walkthrough-Create Azure Function using Azure CLI
- Batch services