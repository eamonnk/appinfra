

This lesson includes the following topics:

- What is Ansible?
- Ansible components
- Installing Ansible
- Ansible on Azure
- Playbook structure
- Run Ansible in Azure Cloud Shell
- Run Ansible in Visual Studio Code
