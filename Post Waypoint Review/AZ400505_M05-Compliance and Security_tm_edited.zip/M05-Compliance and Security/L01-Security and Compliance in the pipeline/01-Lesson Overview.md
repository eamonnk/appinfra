

This lesson includes the following topics:

- What is rugged DevOps?
- Rugged DevOps pipeline
- Software composition analysis (SCA)
- WhiteSource integration with Azure DevOps pipeline
- Micro Focus Fortify integration with Microsoft Azure DevOps pipeline
- Checkmarx integration with Azure DevOps
- How to integrate SCA checks into pipelines
- Veracode integration with Azure DevOp
- DevOps and pipeline security
- Secure DevOps Kit for Microsoft Azure
