In the following steps we will create a virtual machine scale set (VM scale set), deploy a sample application, and configure traffic access with Azure Load Balancer. 


### Prerequisites
- You require an Azure subscription to perform the following steps. If you don't have one, you can create one by following the steps outlined on the <a href="https://azure.microsoft.com/en-us/free/?ref=microsoft.com&utm_source=microsoft.com&utm_medium=docs&utm_campaign=visualstudio" target="_blank"><span style="color: #0066cc;" color="#0066cc">Create your Azure free account today</span></a> webpage.

> **Note**: If you use your own values for the parameters used in the following commands, such as resource group name and scale set name, remember to change them in the subsequent commands as well to ensure the commands run successfully.

### Steps

1. Create a scale set. Before you can create a scale set, you must create a resource group using the following command:
    
    ```bash
    az group create --name myResourceGroup --location < your closest datacenter > 
    ```
    
    Now create a virtual machine scale set with the following command:
    
    ```bash
    az vmss create \
      --resource-group myResourceGroup \
      --name myScaleSet \
      --image UbuntuLTS \
      --upgrade-policy-mode automatic \
      --admin-username azureuser \
      --generate-ssh-keys
    ```
    This creates a scale set named **myScaleSet** that is set to automatically update as changes are applied. It also generates Secure Shell (SSH) keys if they do not exist in *~/.ssh/id_rsa.*
    
2. Deploy a sample application. To test your scale set, install a basic web application, and a basic NGINX web server. The Azure Custom Script Extension (CSE) downloads and runs a script that installs the sample web application on the VM instance (or instances). To install the basic web application, run the following command:

    ```bash
    az vmss extension set \
      --publisher Microsoft.Azure.Extensions \
      --version 2.0 \
      --name CustomScript \
      --resource-group myResourceGroup \
      --vmss-name myScaleSet \
      --settings '{"fileUris":["https://raw.githubusercontent.com/Microsoft/PartsUnlimitedMRP/master/Labfiles/AZ-400T05-ImplemntgAppInfra/Labfiles/automate_nginx.sh"],"commandToExecute":"./automate_nginx.sh"}'
    ```

3. Allow traffic to access the application. When you created the scale set, the Azure Load Balancer deployed automatically. As a result, traffic distributes to the VM instances in the scale set. To allow traffic to reach the sample web application, create a load balancer rule with the following command:
    
    ```bash
    az network lb rule create \
      --resource-group myResourceGroup \
      --name myLoadBalancerRuleWeb \
      --lb-name myScaleSetLB \
      --backend-pool-name myScaleSetLBBEPool \
      --backend-port 80 \
      --frontend-ip-name loadBalancerFrontEnd \
      --frontend-port 80 \
      --protocol tcp
    ```

4. Obtain the public IP Address. To test your scale set and observe your scale set in action, access the sample web application in a web browser, and then obtain the public IP address of your load balancer using the following command:
    
    ```bash
    az network public-ip show \
      --resource-group myResourceGroup \
      --name myScaleSetLBPublicIP \
      --query '[ipAddress]' \
      --output tsv
    ```

5. Test your scale set. Enter the public IP address of the load balancer in a web browser. The load balancer distributes traffic to one of your VM instances, as in the following screenshot:

    <p style="text-align:center;"><img src="../Linked_Image_Files/vmsswalkthrough4.png" alt="Screenshot of a web browser address bar with a sample application hosted on a vm scale set via a load balancer."></p>

6. Remove the resource group, scale set, and all related resources as follows. The *--no-wait* parameter returns control to the prompt without waiting for the operation to complete. The *--yes* parameter confirms that you wish to delete the resources without an additional prompt to do so.

    ```bash
    az group delete --name myResourceGroup --yes --no-wait
    ```

