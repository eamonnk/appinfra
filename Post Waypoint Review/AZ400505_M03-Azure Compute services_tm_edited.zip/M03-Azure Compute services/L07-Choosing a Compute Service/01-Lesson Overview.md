

This lesson includes the following topics:

- IaaS vs. PaaS vs. FaaS
- Azure compute options
- Choosing a compute service
