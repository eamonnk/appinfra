

This lesson includes the following topics:

- Architecture models
- N-Tier
- Web-queue-worker
- Microservices
- CQRS.
- Event-driven
- Big data
- Big compute
