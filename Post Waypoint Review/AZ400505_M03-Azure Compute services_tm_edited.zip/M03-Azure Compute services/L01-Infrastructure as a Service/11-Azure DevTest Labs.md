*Azure DevTest Labs* enables you to quickly set up an environment for your team (for example: development or test environment) in the cloud. A lab owner creates a lab, provisions Windows VMs or Linux VMs, installs the necessary software and tools, and makes them available to lab users. Lab users connect to the VMs in the lab, and use them for their day-to-day short-term projects. Once users start utilizing resources in the lab, a lab admin can analyze cost and usage across multiple labs, and set overarching policies to optimize their organization's or team's costs.

> **Note**: Azure DevTest Labs is being expanded with new types of labs, namely Azure Lab Services, which lets you create managed labs, such as classroom labs. The service itself handles all the infrastructure management for a managed lab, from starting VMs to managing errors, to scaling the infrastructure. 
> 
> The managed labs are currently in preview. Once the preview ends, the new lab types and existing DevTest Labs will be under the new common umbrella name of *Azure Lab Services*, where all lab types continue to evolve.

### Usage scenarios
Some common use cases for using *Azure DevTest Labs* are as follows:

- Use DevTest Labs for development environments. This enables you to host development machines for developers so they can:
    - Quickly provision their development machines on demand.
    - Provision Windows and Linux environments using reusable templates and artifacts.
    - More easily customize their development machines whenever needed.

- Use DevTest Labs for test environments. This enables you to host machines for testers so they can:
    - Test the latest version of their application by quickly provisioning Windows and Linux environments using reusable templates and artifacts.
    - Scale up their load testing by provisioning multiple test agents.
      
    In addition, administrators can use DevTest Labs to control costs by ensuring that testers cannot get more VMs than they need for testing, and VMs are shut down when not in use.

- Integrate DevTest Labs with Azure DevOps CI/CD pipeline. You can use the Azure DevTest Labs Tasks extension that's installed in Azure DevOps to easily integrate your CI/CD build-and-release pipeline with Azure DevTest Labs. The extension installs three tasks: 
    - Create a VM
    - Create a custom image from a VM
    - Delete a VM 

    The process makes it easy to—for example—quickly deploy an image for a specific test task, and then delete it when the test completes.

> **Note**: For more information on DevTest Labs, go to 
<a href="https://docs.microsoft.com/en-us/azure/lab-services/" target="_blank"><span style="color: #0066cc;" color="#0066cc">Azure Lab Services Documentation</span></a>.