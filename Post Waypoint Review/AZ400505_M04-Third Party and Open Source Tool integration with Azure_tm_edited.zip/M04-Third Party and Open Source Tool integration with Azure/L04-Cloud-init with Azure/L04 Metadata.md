###### Enter the Lesson Title
```
Lesson title: Cloud-init with Azure
```
