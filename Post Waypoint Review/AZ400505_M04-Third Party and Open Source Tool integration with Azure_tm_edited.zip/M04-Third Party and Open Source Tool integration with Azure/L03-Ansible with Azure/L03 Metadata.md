###### Enter the Lesson Title
```
Lesson title: Ansible with Azure
```
