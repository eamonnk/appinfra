

This lesson includes the following topics:

- Azure Security Center
- Azure Security Center usage scenarios
- Azure Policy
- Policies
- Initiatives
- Azure Key Vault
- RBAC
- Locks
- Subscription governance
- Azure Blueprints
- Azure Advanced Threat Protection
