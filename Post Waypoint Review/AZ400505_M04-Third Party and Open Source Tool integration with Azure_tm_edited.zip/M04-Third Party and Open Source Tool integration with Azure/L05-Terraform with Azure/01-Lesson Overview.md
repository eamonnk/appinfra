

This lesson includes the following topics:

- What is Terraform?
- Terraform components
- Terraform on Azure
- Installing Terraform
- Terraform config file structure
- Run Terraform in Azure Cloud Shell
- Run Terraform in Visual Studio Code