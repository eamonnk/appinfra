Two important areas from the Rugged DevOps pipeline are Package management and Open Source Software OSS components.

### Package management

Just as teams use version control as a single source of truth for source code, Rugged DevOps relies on a package manager as the unique source of binary components. By using binary package management, a development team can create a local cache of approved components, and make this a trusted feed for the Continuous Integration (CI) pipeline.

In Azure DevOps, *Azure Artifacts* is an integral part of the component workflow for organizing and sharing access to your packages. Azure Artifacts allows you to:

- Keep your artifacts organized. Share code easily by storing Apache Maven, npm, and NuGet packages together. You can store packages using Universal Packages, eliminating the need to store binaries in Git.
- Protect your packages. Keep every public source package you use (including packages from npmjs and NuGet .org) safe in your feed where only you can delete it and where it's backed by the enterprise-grade Azure Service Level Agreement (SLA).
- Integrate seamless package handling into your Continuous Integration (CI)/ Continuous Development (CD) pipeline. Easily access all your artifacts in builds and releases. Azure Artifacts integrates natively with the Azure Pipelines CI/CD tool.

For more information about Azure Artifacts, visit the webpage <a href="https://docs.microsoft.com/en-us/azure/devops/artifacts/overview?view=vsts" target="_blank"><span style="color: #0066cc;" color="#0066cc">What is Azure Artifacts?</span></a>

#### Versions and compatibility

The following table lists the package types supported by Azure Artifacts. The availability of each package in *Azure DevOps Services* also displays. The following table details the compatibility of each package with specific versions of Azure DevOps Server, previously known as *Team Foundation Server* (TFS).

|Feature|Azure DevOps Services|TFS|
|---|---|---
|NuGet|Yes|TFS 2017|
|npm|Yes|TFS 2017 update 1 and later|
|Maven|Yes|TFS 2017 update 1 and later|
|Gradle|Yes|TFS 2018|
|Universal|Yes|No|
|Python|Yes|No|


Maven, npm, and NuGet packages can be supported from public and private sources with teams of any size. Azure Artifact comes with Azure DevOps, but the extension is also available from the <a href="https://marketplace.visualstudio.com/items?itemName=ms.feed" target="_blank"><span style="color: #0066cc;" color="#0066cc">Visual Studio Marketplace Azure DevOps page</span></a>.


<p style="text-align:center;"><img src="../Linked_Image_Files/azartifact1.png" alt="Screenshot of Azure DevOps with Artifacts highlighted in the menu pane. In the connect to feed pane, package types NuGet, npm, Maven, Gradle, Universal, and Python are highlighted."></p>

> **Note**: After you publish a particular version of a package to a feed, that version number is permanently reserved. You cannot upload a newer revision package with that same version number, or delete that version and upload a new package with the same version number. The published version is immutable.

### The Role of OSS components
Development work is more productive as a result of the wide availability of reusable Open-source software (OSS) components. This practical approach to reuse includes runtimes, which are available on Windows and Linux operating systems such as Microsoft .NET Core and Node.js.

However, OSS component reuse comes with the risk that reused dependencies can have security vulnerabilities. As a result, many users find security vulnerabilities in their applications due to the Node.js package versions they consume.

To address these security concerns, OSS offers a new concept called *Software Composition Analysis (SCA)*, which is depicted in the following image.

<p style="text-align:center;"><img src="../Linked_Image_Files/ruggeddevops4.png" alt="A image of the workflow for safely creating open-source dependencies. Software Composition Analysis, Developer Team, Version Control, Build Server, Trusted Feed, External Package Feed, and Package Scanner are the main categories."></p>

When consuming an OSS component, whether you are creating or consuming dependencies, you'll typically want to follow these high-level steps:

1. Start with the latest, correct version to avoid any old vulnerabilities or license misuses.
2. Validate that the OSS components are the correct binaries for your version. In the release pipeline, validate binaries to ensure that they are correct and to keep a traceable bill of materials.
3. Get notifications of component vulnerabilities immediately, and correct and redeploy the component automatically to resolve security vulnerabilities or license misuses from reused software.


