The Git folder for Module graphics: $/{COURSE}/Modules/Linked_Image_Files/{ImageFileName}

Upload your graphic files directly under "Linked_Image_Files" folder.
Upload you downloadable PDF, PPT, ZIP files to "Linked_Image_Files" folder.