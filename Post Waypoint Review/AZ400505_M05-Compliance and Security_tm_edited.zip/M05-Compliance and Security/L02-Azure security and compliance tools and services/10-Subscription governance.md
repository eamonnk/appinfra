
The following considerations apply to creating and managing Azure subscriptions:

- Billing. You can generate billing reports for Azure subscriptions. If, for example, you have multiple internal departments and need to perform a chargeback, you can create a subscription for a department or project.

- Access control. A subscription acts as a deployment boundary for Azure resources. Every subscription is associated with an Azure Active Directory (Azure AD) tenant that provides administrators with the ability to set up RBAC. When designing a subscription model, consider the deployment boundary. Some customers keep separate subscriptions for development and production, and manage them using RBAC to isolate one subscription from the other (from a resource perspective).

- Subscription limits. Subscriptions are bound by hard limitations. For example, the maximum number of Azure ExpressRoute circuits per subscription is 10. If you reach a limit, there is no flexibility. Keep these limits in mind during your design phase. If you need to exceed the limits, you might require additional subscriptions.

### Management groups

Management Groups can assist you with managing your Azure subscriptions. *Management groups* manage access, policies, and compliance across multiple Azure subscriptions. They allow you to order your Azure resources hierarchically into collections. Management groups facilitate the management of resources at a level above the level of subscriptions.

In the following image, access is divided across different regions and business functions, such as marketing and IT. This helps you track costs and resource usage at a granular level, add security layers, and segment workloads. You could even divide these areas further into separate subscriptions for Dev and QA, or for specific teams.

<p style="text-align:center;"><img src="../Linked_Image_Files/subscriptions1-2.png" alt="Tree diagram representing Azure subscription management groups and how they can be structured for use as deployment boundaries."></p>

You can manage your Azure subscriptions more effectively by using Azure Policy and Azure RBACs. These tools provide distinct governance conditions that you can apply to each management group. Any conditions that you apply to a management group will automatically be inherited by the resources and subscriptions within that group.

> **Note**: For more information about management groups and Azure, go to the <a href="https://docs.microsoft.com/en-us/azure/governance/management-groups/" target="_blank"><span style="color: #0066cc;" color="#0066cc">Azure management groups documentation, Organize your resources</span></a> webpage.
